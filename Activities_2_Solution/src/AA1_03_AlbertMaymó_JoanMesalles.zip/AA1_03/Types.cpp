#include "Types.h"

int InputData::GetNumberInputs()
{
    return (int)InputKeys::COUNT;
}
